class Povchien < ActiveRecord::Migration[7.0]
  def change
    add_reference :dogsitters ,:city
    add_reference :dogs, :city
    add_reference :strolls, :city
  end
end
