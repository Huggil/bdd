#Création des promeneurs et des chiens
dogsitter1 = Dogsitter.new(name: "John", age: 26)
dogsitter1.city = paris
dogsitter1.save
dogsitter2 = Dogsitter.new(name: "Bob", age: 24)
dogsitter2.city = paris
dogsitter2.save
dogsitter3 = Dogsitter.new(name: "Louanne", age: 22)
dogsitter3.city = lille
dogsitter3.save
dog1 = Dog.new(name: "Johnny")
dog1.city = paris
dog1.save
dog2 = Dog.new(name: "Henry II")
dog2.city = lille
dog2.save
dog3 = Dog.new(name: "DogGynéco")
dog3.city = lille
dog3.save
puts "3 dogsitters et 3 dogs ajoutés"

#Création des promenades
stroll1 = Stroll.new
stroll1.dogsitter = dogsitter1
stroll1.dog = dog1
stroll1.save
stroll2 = Stroll.new
stroll2.dogsitter = dogsitter1
stroll2.dog = dog3
stroll2.save
stroll3 = Stroll.new
stroll3.dogsitter = dogsitter3
stroll3.dog = dog1
stroll3.save
stroll4 = Stroll.new
stroll4.dogsitter = dogsitter3
stroll4.dog = dog2
stroll4.save
stroll5 = Stroll.new
stroll5.dogsitter = dogsitter3
stroll5.dog = dog3
stroll5.save
stroll6 = Stroll.new
stroll6.dogsitter = dogsitter2
stroll6.dog = dog2
stroll6.save
puts "Différentes promenades ajoutées"