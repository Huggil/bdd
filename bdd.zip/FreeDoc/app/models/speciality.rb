class Speciality < ApplicationRecord
    has_many :doctors
end
