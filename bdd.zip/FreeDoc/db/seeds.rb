# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)
Doctor.create(first_name: "hugo", last_name: "lemusclé", zip_code: "69002")
Doctor.create(first_name: "alex", last_name: "lefortiche", zip_code: "69978")
Doctor.create(first_name: "franck", last_name: "bigbrain", zip_code: "69003")
# puts "3 médecins crées"

Patient.new(first_name: "robert", last_name: "campagne")
Patient.new(first_name: "Juan", last_name: "delavega")
Patient.new(first_name: "sophie", last_name: "marceau")
# puts "3 patients crées"

Appointment.new(date: 2020-01-18 10:00:00)
Appointment.new(date: 2018-03-09 15:15:00)
Appointment.new(date: 2015-11-25 17:30:00)

Specialty.new(specialty: "Kinésitherapeute")
Specialty.new(specialty: "Dermatologue")
Specialty.new(specialty: "Généraliste")
Specialty.new(specialty: "Podologue")

City.new(city: "Paris")
City.new(city: "Bordeaux")
City.new(city: "Lyon")
City.new(city: "Lille")